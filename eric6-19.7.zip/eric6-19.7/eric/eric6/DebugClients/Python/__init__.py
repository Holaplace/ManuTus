# -*- coding: utf-8 -*-

# Copyright (c) 2005 - 2019 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the standard Python debugger.

It consists of different kinds of debug clients.
"""
